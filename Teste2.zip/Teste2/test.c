#include <stdio.h>
#include <stdlib.h>

int identificacao() {
    return "1";
}

int main() {
     int n,m,x;
      n = 1;
      m = identificacao();
      x = 5;
    while(x > n){
         n = n+m;
        puts(identificacao());
    }
}
